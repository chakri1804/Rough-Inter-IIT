#include <stdio.h>

int main()
{
	printf("[");
	for (int i = 0; i < 288; ++i)
	{
		printf("'Ammunition',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Breacher',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Column Formation',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Come',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Cover This Area',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Crouch',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Dog',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Door',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Enemy',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'File Formation',");
	}
	for (int i = 0; i < 576; ++i)
	{
		printf("'Freeze',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Gas',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Hostage',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Hurry Up',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'I Dont Understand',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'I Understand',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Leader',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Line Formation',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Listen',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Me',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Move Up',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Pistol',");
	}
	for (int i = 0; i < 287; ++i)
	{
		printf("'Point Of Entry',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Rally Point',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Rifle',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'See',");
	}	
	for (int i = 0; i < 264; ++i)
	{
		printf("'Shotgun',");
	}	
	for (int i = 0; i < 288; ++i)
	{
		printf("'Sniper',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Stop',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Vehicle',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Wedge Formation',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'Window',");
	}
	for (int i = 0; i < 288; ++i)
	{
		printf("'You',");
	}
	printf("]\n");
	return 0;
}