#include <stdio.h>

int main(int argc, char const *argv[])
{
	printf("[");
	for (int i = 0; i < 576; ++i)
	{
		printf("'See', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'listen', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'me', ");
	}
	for (int i = 0; i < 432; ++i)
	{
		printf("'stop', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'you', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'breach', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'cell_leader', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'cover_area', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'dog', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'enemy', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'freeze', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'gas', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'hostage', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'line_abreast', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'pistol', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'rifle', ");
	}
	for (int i = 0; i < 240; ++i)
	{
		printf("'sniper', ");
	}
	printf("]\n");
	return 0;
}