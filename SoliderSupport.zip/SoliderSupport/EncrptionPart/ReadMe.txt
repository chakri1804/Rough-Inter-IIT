--------------
To Generate Key

# gpg --gen-key

# gpg --export -a "IIT Hyderabad" > public.key

# gpg --export-secret-key -a "IIT Hyderabad" > private.key

# gpg --import public.key

# gpg --allow-secret-key-import --import private.key

UserName : IIT Hyderabad
Password : e****a
