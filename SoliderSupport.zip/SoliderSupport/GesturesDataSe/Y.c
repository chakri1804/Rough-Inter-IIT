#include <stdio.h>

int main(int argc, char const *argv[])
{
	printf("[");
	for (int i = 0; i < 230; ++i)
	{
		printf("'you', ");
	}
	for (int i = 0; i < 230; ++i)
	{
		printf("'watch', ");
	}
	for (int i = 0; i < 230; ++i)
	{
		printf("'stop', ");
	}
	for (int i = 0; i < 231; ++i)
	{
		printf("'sniper', ");
	}
	for (int i = 0; i < 230; ++i)
	{
		printf("'me', ");
	}
	for (int i = 0; i < 414; ++i)
	{
		printf("'listen', ");
	}
	for (int i = 0; i < 230; ++i)
	{
		printf("'hostage', ");
	}
	for (int i = 0; i < 230; ++i)
	{
		printf("'freeze', ");
	}
	for (int i = 0; i < 508; ++i)
	{
		printf("'coverthisarea', ");
	}
	printf("]\n");
	return 0;
}