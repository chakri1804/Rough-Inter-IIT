import pickle

filename = 'fingers_model.sav'
loaded_model = pickle.load(open(filename, 'rb'))
names = ['One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten']

# val = [1423, 2674, 2407, 2065, 2177, 355.6943, 42.30696, 355.2917, -53.92366, -23.91603, 81.0458, 176.082, 106.8297, 1.077965, 6.175572, 15.29008, -27.41221],
val = [1307, 4095, 1664, 1621, 1710],

# Testing 
output = loaded_model.predict(val)
print(output[0])
# Printing Probability
proba = (loaded_model.predict_proba(val))

for x in xrange(0,len(proba[0])):
	if proba[0][x]:
		print proba[0][x], "-", names[x]
		pass
	pass