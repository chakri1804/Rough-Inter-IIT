#include <stdio.h>

int main()
{
	printf("[");
	for (int i = 0; i < 174; ++i)
	{
		printf("'One',");
	}
	for (int i = 0; i < 174; ++i)
	{
		printf("'Two',");
	}
	for (int i = 0; i < 171; ++i)
	{
		printf("'Three',");
	}
	for (int i = 0; i < 210; ++i)
	{
		printf("'Four',");
	}
	for (int i = 0; i < 210; ++i)
	{
		printf("'Five',");
	}
	for (int i = 0; i < 168; ++i)
	{
		printf("'Six',");
	}
	for (int i = 0; i < 168; ++i)
	{
		printf("'Seven',");
	}
	for (int i = 0; i < 168; ++i)
	{
		printf("'Eight',");
	}
	for (int i = 0; i < 168; ++i)
	{
		printf("'Nine',");
	}
	for (int i = 0; i < 168; ++i)
	{
		printf("'Ten',");
	}
	printf("]\n");
	return 0;
}